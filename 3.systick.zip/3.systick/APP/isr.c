#include "isr.h"

volatile u32 systime_ms = 0; 
/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
	systime_ms++;
}

