#include "delay.h"
#include "isr.h"


void systick_Init(void){
	SysTick_Config(SystemCoreClock / 1000);
}

/**
  * @brief  Decrements the TimingDelay variable.
  * @param  None
  * @retval None
  */
void sysdelay_ms(u16 ms)
{
	u32 end_time = systime_ms+ms;
  while( systime_ms < end_time)
  {
    ;
  }
}


//���뼶����ʱ
void delay_ms(u16 time)
{
	u16 i=0;
	while(time--)
	{
		i=12000;  //�Լ�����
		while(i--) ;
  }
}









