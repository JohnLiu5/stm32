#ifndef _DELAY_H
#define _DELAY_H

#include "stm32f10x.h"



	
void systick_Init(void);
void sysdelay_ms(u16 ms);
void delay_ms(u16 time);


#endif











