#include "stm32f10x.h"
#include "led.h"
#include "delay.h"

 

int main()
{
	//systick_Init();
	LED_Init();
	while(1)
	{
		GPIO_ResetBits(GPIOC,GPIO_Pin_13);
		//sysdelay_ms(500);
		delay_ms(500);
		GPIO_SetBits(GPIOC,GPIO_Pin_13);
		//sysdelay_ms(500);
		delay_ms(500);
	}
}
